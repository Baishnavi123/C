#include <stdio.h>

int main()
{
    int a;
    printf("click me 1,2,3,4,5-");
    scanf("%d",&a);
    switch(a)
    {
        case 1 :
    printf("hello");
    break;
    case 2 :
    printf("namaste");
    break;
    case 3 :
    printf("wadakam");
    break;
    case 4 :
    printf("juhar");
    break;
    case 5 :
    printf("pranam");
    break;
    default:
    printf("i am still learning");
}
    return 0;
}
