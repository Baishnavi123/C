#include <stdio.h>

int main()
{
   char c;
    printf("click on +,-,*,/:");
    scanf("%c",&c);
   int a,b,d;
    printf("enter the value a: ");
    scanf("%d",&a);
    printf("enter the value b: ");
    scanf("%d",&b);
    
   
    switch(c)
    {
   case '+':
   ( d=a+b);
    printf("%d",d);
   break;
    case '-':
   (d=a-b);
    printf("%d",d);
   break;
    case '*':
   ( d=a*b);
    printf("%d",d);
   break;
    case '/':
    (d=a/b);
    printf("%d",d);
     break;
     
    default:
    printf("i am still learning");
}
    return 0;
}
