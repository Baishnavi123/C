
#include <stdio.h>

int main()
{
    char a;
    printf("enter a vowel:a,e,i,o,u-");
    scanf("%c",&a);
    switch(a)
    {
    case ('a'):
    case 'A':
    case 'e':
    case 'E':
    case 'i':
    case 'I':
    case 'o':
    case 'O':
    case 'u':
    case 'U':
    printf("%c is a vowel",a);
     break;
     
    default:
    printf("i am still learning");
}
    return 0;
}
